let board = [["", "", ""], ["", "", ""], ["", "", ""]];
let currentPlayer = "X";
let questions = [];
let answers = [];
let timer;
let timeLeft = 10;

// Função para gerar operações aleatórias
function generateRandomOperations() {
  let operations = ["+", "-", "×", "÷"];
  let tempQuestions = [];
  let tempAnswers = [];

  for (let i = 0; i < 3; i++) {
    let rowQuestions = [];
    let rowAnswers = [];
    for (let j = 0; j < 3; j++) {
      let question;
      let answer;
      let valid = false;

      while (!valid) {
        let num1 = Math.floor(Math.random() * 20) + 1; // Número aleatório entre 1 e 20
        let num2 = Math.floor(Math.random() * 20) + 1; // Número aleatório entre 1 e 20
        let op = operations[Math.floor(Math.random() * operations.length)];

        switch (op) {
          case "+":
            question = `${num1} + ${num2}`;
            answer = num1 + num2;
            valid = true;
            break;
          case "-":
            if (num1 < num2) {
              [num1, num2] = [num2, num1]; // Trocar para garantir resultado positivo
            }
            question = `${num1} - ${num2}`;
            answer = num1 - num2;
            valid = true;
            break;
          case "×":
            question = `${num1} × ${num2}`;
            answer = num1 * num2;
            valid = true;
            break;
          case "÷":
            if (num1 % num2 === 0) {
              question = `${num1} ÷ ${num2}`;
              answer = num1 / num2;
              valid = true;
            }
            // Se não for divisível, tenta novamente
            break;
        }
      }

      rowQuestions.push(question);
      rowAnswers.push(answer);
    }
    tempQuestions.push(rowQuestions);
    tempAnswers.push(rowAnswers);
  }

  questions = tempQuestions;
  answers = tempAnswers;
}

function startTimer() {
  clearInterval(timer);
  timeLeft = 10;
  document.getElementById("timer").innerText = "Tempo restante: " + timeLeft + "s";
  timer = setInterval(() => {
    timeLeft--;
    document.getElementById("timer").innerText = "Tempo restante: " + timeLeft + "s";
    if (timeLeft <= 0) {
      clearInterval(timer);
      playSound('timeUp');
      alert("Tempo esgotado! Vez do próximo jogador.");
      switchPlayer();
    }
  }, 1000);
}

function playSound(type) {
  if (type === 'correct') document.getElementById('correctSound').play();
  if (type === 'error') document.getElementById('errorSound').play();
  if (type === 'win') document.getElementById('winSound').play();
  if (type === 'timeUp') document.getElementById('timeUpSound').play();
}

function chooseCell(row, col) {
  if (board[row][col] !== "") return;

  // Mostra a operação no lugar da célula
  let question = questions[row][col];
  let userAnswer = prompt("Resolva: " + question.replace("×", "*").replace("÷", "/"));

  if (userAnswer === null) return;

  let correctAnswer = answers[row][col];

  if (parseFloat(userAnswer) === correctAnswer) {
    board[row][col] = currentPlayer;
    document.getElementsByTagName("table")[0].rows[row].cells[col].innerText = currentPlayer;
    playSound('correct');
    if (checkWinner()) {
      playSound('win');
      setTimeout(() => alert("💚 JOGADOR " + currentPlayer + " VENCEU! PARABÉNS! 🚀"), 300);
      resetGame();
    } else {
      switchPlayer();
    }
  } else {
    playSound('error');
    alert("Resposta incorreta! Vez do próximo jogador.");
    switchPlayer();
  }
}

function switchPlayer() {
  currentPlayer = currentPlayer === "X" ? "O" : "X";
  document.getElementById("turn").innerText = "Vez de: Jogador " + currentPlayer;
  startTimer();
}

function checkWinner() {
  for (let i = 0; i < 3; i++) {
    if (board[i][0] !== "" && board[i][0] === board[i][1] && board[i][1] === board[i][2]) return true;
    if (board[0][i] !== "" && board[0][i] === board[1][i] && board[1][i] === board[2][i]) return true;
  }
  if (board[0][0] !== "" && board[0][0] === board[1][1] && board[1][1] === board[2][2]) return true;
  if (board[0][2] !== "" && board[0][2] === board[1][1] && board[1][1] === board[2][0]) return true;
  return false;
}

function resetGame() {
  board = [["", "", ""], ["", "", ""], ["", "", ""]];
  let cells = document.getElementsByTagName("td");
  for (let cell of cells) {
    cell.innerText = "";
  }
  currentPlayer = "X";
  document.getElementById("turn").innerText = "Vez de: Jogador X";
  generateRandomOperations(); // Gerar operações aleatórias ao reiniciar o jogo
  startTimer();
}

generateRandomOperations(); // Gerar operações aleatórias quando a página for carregada
startTimer();

